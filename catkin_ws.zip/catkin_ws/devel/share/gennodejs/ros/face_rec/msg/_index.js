
"use strict";

let face_results = require('./face_results.js');
let face_data = require('./face_data.js');

module.exports = {
  face_results: face_results,
  face_data: face_data,
};
